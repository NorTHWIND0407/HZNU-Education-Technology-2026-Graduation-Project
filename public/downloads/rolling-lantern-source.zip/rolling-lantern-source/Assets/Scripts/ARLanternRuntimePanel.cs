using UnityEngine;

public class ARLanternRuntimePanel : MonoBehaviour
{
    [Header("Reference")]
    public ARTapToPlaceRollingLantern placementController;

    [Header("UI")]
    public bool showPanel = true;
    [Min(0f)] public float minRpm = 0f;
    [Min(1f)] public float maxRpm = 30f;

    private Rect _panelRect = new Rect(20f, 20f, 320f, 240f);
    private RollingLanternMVP _lastLantern;
    private float _rpm = 12f;
    private float _outerRpm = 8f;
    private static ARLanternRuntimePanel _activePanel;

    private void Awake()
    {
        if (placementController == null)
        {
            placementController = FindObjectOfType<ARTapToPlaceRollingLantern>();
        }
    }

    private void OnEnable()
    {
        if (_activePanel != null && _activePanel != this)
        {
            enabled = false;
            return;
        }

        _activePanel = this;
    }

    private void OnDisable()
    {
        if (_activePanel == this)
        {
            _activePanel = null;
        }
    }

    private void OnGUI()
    {
        if (!showPanel)
        {
            return;
        }

        RollingLanternMVP lantern = placementController != null ? placementController.CurrentLantern : null;
        if (lantern != _lastLantern)
        {
            _lastLantern = lantern;
            if (lantern != null)
            {
                _rpm = lantern.spinRpm;
                _outerRpm = lantern.outerSpinRpm;
            }
        }

        GUILayout.BeginArea(_panelRect, GUI.skin.box);
        GUILayout.Label("滚灯控制面板");
        GUILayout.Space(4f);

        if (lantern == null)
        {
            GUILayout.Label("状态：请点击已识别平面放置滚灯");
        }
        else
        {
            GUILayout.Label("状态：滚灯已放置");
        }

        GUI.enabled = lantern != null;

        GUILayout.Space(8f);
        GUILayout.Label($"转速 RPM：{_rpm:0.0}");

        float clampedMax = Mathf.Max(minRpm + 0.01f, maxRpm);
        float nextRpm = GUILayout.HorizontalSlider(_rpm, minRpm, clampedMax);
        if (lantern != null && Mathf.Abs(nextRpm - _rpm) > 0.001f)
        {
            _rpm = nextRpm;
            lantern.SetSpinRpm(_rpm);
        }

        GUILayout.Space(8f);
        GUILayout.Label($"外球转速 RPM：{_outerRpm:0.0}");
        float nextOuterRpm = GUILayout.HorizontalSlider(_outerRpm, minRpm, clampedMax);
        if (lantern != null && Mathf.Abs(nextOuterRpm - _outerRpm) > 0.001f)
        {
            _outerRpm = nextOuterRpm;
            lantern.SetOuterSpinRpm(_outerRpm);
        }

        GUILayout.Space(8f);
        GUILayout.Label(lantern != null
            ? $"风格：{GetStyleLabel(lantern.style_type)}  默认尺寸：{GetScaleLabel(lantern.scale_type)}"
            : "风格：-  默认尺寸：-");

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("文灯"))
        {
            lantern.style_type = LanternStyleType.Wen;
            lantern.BuildLantern();
        }
        if (GUILayout.Button("武灯"))
        {
            lantern.style_type = LanternStyleType.Wu;
            lantern.BuildLantern();
        }
        GUILayout.EndHorizontal();

        GUILayout.Space(8f);
        if (lantern != null)
        {
            GUILayout.Label("操作：拖拽滚灯可旋转外球");
            GUILayout.Label("缩放：鼠标滚轮 / 双指捏合");
        }

        if (GUILayout.Button("切换配色"))
        {
            lantern.NextPalette();
        }

        GUI.enabled = placementController != null;
        if (GUILayout.Button("重置放置"))
        {
            placementController.ClearPlacedLantern();
            _lastLantern = null;
        }

        GUI.enabled = true;
        GUILayout.EndArea();
    }

    private static string GetStyleLabel(LanternStyleType style)
    {
        return style == LanternStyleType.Wen ? "文灯" : "武灯";
    }

    private static string GetScaleLabel(LanternScaleType scale)
    {
        switch (scale)
        {
            case LanternScaleType.Small:
                return "小";
            case LanternScaleType.Medium:
                return "中";
            case LanternScaleType.Large:
                return "大";
            default:
                return "-";
        }
    }
}
