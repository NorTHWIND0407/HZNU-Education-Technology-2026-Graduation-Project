# Unity 项目转 WebAR（新手分步）

## 先说结论
`AR Foundation` 不能直接原样导出成可用的 `WebAR`。
你需要保留当前 Unity 版本作为 iOS/Android 原生 AR，同时新建一个 Web 项目实现同样交互。

## 目标拆分（和你当前项目对齐）
1. 扫描环境/识别目标后放置滚灯
2. 点击或拖拽滚灯进行交互（切换样式、旋转）
3. 手机网页里启动摄像头

## 第 1 步：导出滚灯模型资源
1. 在 Unity 里把滚灯做成 Prefab（你现在运行时也可生成，建议额外做一个静态展示 Prefab 用于导出）。
2. 用 `FBX Exporter` 导出为 `.fbx`，再用 Blender 转 `.glb`（Web 端最常用）。
3. 贴图尽量使用 `PNG/JPG`，并确认材质在 Web 渲染器里可还原。

## 第 2 步：新建 Web 项目（推荐 Three.js）
1. 新建前端项目（如 Vite + Three.js）。
2. 放入导出的 `rolling-lantern.glb`。
3. 先在非 AR 模式下把模型加载、旋转、换材质功能跑通。

## 第 3 步：先实现“开始摄像头”
> 先把这步做通，再接 AR 追踪。

### `index.html`
```html
<button id="startCameraBtn">开始摄像头</button>
<video id="camera" autoplay playsinline muted></video>
```

### `main.js`
```js
const startBtn = document.getElementById('startCameraBtn');
const video = document.getElementById('camera');

startBtn.addEventListener('click', async () => {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment' },
      audio: false,
    });
    video.srcObject = stream;
    startBtn.style.display = 'none';
  } catch (err) {
    alert('摄像头启动失败：' + err.message);
  }
});
```

### 注意事项
1. 必须 `HTTPS` 或 `localhost` 才能调起摄像头。
2. iOS Safari 必须用户手势触发（按钮点击）后才能开摄像头。
3. 页面要有权限弹窗，首次可能被系统拦截，需手动允许。

## 第 4 步：选择 WebAR 方案
### 方案 A（更容易上手）
`MindAR + Three.js`（图像追踪/标记追踪）
- 适合先跑通“识别图后出现滚灯”。
- 对新手最友好。

### 方案 B（更接近原生平面放置）
`WebXR Hit Test`
- 适合做“检测平面后放置滚灯”。
- 平台支持受浏览器和机型限制更大（常见是 Android Chrome 更友好）。

## 第 5 步：把你当前交互迁移过去
1. 点击模型：切换配色（对应你现在 `NextPalette()`）。
2. 单指拖拽：绕 `Y` 轴旋转（对应你刚加的旋转能力）。
3. UI 按钮：文灯/武灯、小中大、重置。

## 第 6 步：部署与真机测试
1. 部署到支持 HTTPS 的平台（Vercel/Netlify/自建 Nginx）。
2. 用手机打开页面，先测“开始摄像头”。
3. 再测 AR 跟踪与模型交互。

## 常见坑排查
1. 黑屏：通常是权限未授权或非 HTTPS。
2. 有画面但没 AR：追踪库未初始化、相机参数或目标图不匹配。
3. 模型太卡：减面、压缩贴图、减少实时灯光。

## 建议你现在就做的最小闭环
1. 先完成“按钮点击 -> 启动后置摄像头”。
2. 再叠加 Three.js 渲染滚灯 `.glb`。
3. 最后接入 MindAR 或 WebXR。

这样可以最快把 WebAR 跑起来，再逐步逼近你 Unity 版本的效果。
