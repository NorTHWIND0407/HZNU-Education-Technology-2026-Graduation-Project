using UnityEngine;

[System.Serializable]
public class LanternPalette
{
    public string paletteName = "Default";
    public Color frameColor = new Color(0.92f, 0.70f, 0.16f, 1f);
    public Color innerShellColor = new Color(0.88f, 0.08f, 0.10f, 1f);
    public Color coreColor = new Color(1.00f, 0.24f, 0.14f, 1f);
}

public enum LanternScaleType
{
    Small,
    Medium,
    Large
}

public enum LanternStyleType
{
    Wen,
    Wu
}

public enum LanternSuspensionType
{
    SingleAxis,
    DualAxis,
    Gimbal
}

public enum LanternCoverType
{
    BareBamboo,
    Paper,
    Cloth
}

public enum LanternLightType
{
    Candle,
    LED
}

[System.Serializable]
public class RollingLanternModelParams
{
    public float D_outer = 0.36f;
    public float D_inner = 0.12f;
    public int n_outer_ribs = 12;
    public int n_inner_ribs = 6;
    public float rib_width = 0.008f;
    public float rib_thickness = 0.004f;
    public int n_equator_bands = 3;
    public LanternSuspensionType suspension_type = LanternSuspensionType.DualAxis;
    public float suspension_offset = 0f;
    public LanternCoverType cover_type = LanternCoverType.Cloth;
    public LanternStyleType style_type = LanternStyleType.Wen;
    public float chain_weight = 0f;
    public LanternLightType light_type = LanternLightType.LED;
    public LanternScaleType scale_type = LanternScaleType.Large;
}

public class RollingLanternMVP : MonoBehaviour
{
    private const int TraditionalOuterOrbitCount = 12;
    private const int DefaultOuterRingCount = 3;
    private const int LargeOuterRingCount = 4;
    private const int MaxOuterRingCount = 4;
    private const float OuterRingMaxOffsetFactor = 0.52f;

    [Header("Scale Preset")]
    public LanternScaleType scale_type = LanternScaleType.Large;
    public bool applyScalePreset = true;

    [Header("Free Scale")]
    [Min(0.1f)] public float overallScale = 1f;

    [Header("Core Parameters (meters)")]
    [Min(0.15f)] public float D_outer = 0.36f;
    [Min(0.05f)] public float D_inner = 0.12f;
    [Min(6)] public int n_outer_ribs = 12;
    [Min(4)] public int n_inner_ribs = 6;
    [Min(0.002f)] public float rib_width = 0.008f;
    [Min(0.001f)] public float rib_thickness = 0.004f;
    [Range(0, 8)] public int n_equator_bands = 3;
    [Range(0f, 0.08f)] public float suspension_offset = 0f;

    [Header("Structure")]
    public LanternSuspensionType suspension_type = LanternSuspensionType.DualAxis;
    public bool showSuspensionFrame = false;
    public LanternCoverType cover_type = LanternCoverType.Cloth;
    public LanternStyleType style_type = LanternStyleType.Wen;
    [Range(0f, 50f)] public float chain_weight = 0f;
    public LanternLightType light_type = LanternLightType.LED;

    [Header("Geometry Controls")]
    [Min(12)] public int arcSegments = 28;
    [Range(0f, 0.12f)] public float cageIrregularity = 0f;
    [Range(0f, 35f)] public float ribTiltDegrees = 16f;

    [Header("Inner Motion")]
    public bool spinInnerLamp = true;
    [Min(0f)] public float spinRpm = 12f;
    [Range(0f, 12f)] public float stabilizationStrength = 2f;

    [Header("Outer Motion")]
    public bool spinOuterLantern = true;
    [Min(0f)] public float outerSpinRpm = 8f;

    [Header("Styles")]
    public LanternPalette[] palettes;
    [Min(0)] public int initialPaletteIndex = 0;

    [Header("Interaction")]
    public bool addInteractionCollider = true;
    [Min(1f)] public float interactionColliderScale = 1.08f;

    [Header("Center Traction Lines")]
    public bool addDualTractionLines = true;
    [Min(0.0005f)] public float tractionLineWidth = 0.0022f;
    [Min(0.0005f)] public float tractionLineThickness = 0.0022f;

    [Header("Inner Lamp Support")]
    public bool addInnerSupportRing = true;
    [Range(0.55f, 1.1f)] public float innerSupportRingScale = 0.92f;

    [Header("Build")]
    public bool buildOnStart = true;
    public bool showDebugAxes = false;

    private Transform _innerRoot;
    private Transform _outerRoot;
    private Transform _suspensionPivot;
    private Light _innerLight;
    private int _paletteIndex;
    private bool _palettesInitialized;
    private float _candleSeed;

    public int CurrentPaletteIndex => _paletteIndex;

    private float OuterRadius => D_outer * 0.5f;
    private float InnerRadius => D_inner * 0.5f;

    private void Start()
    {
        EnsurePalettes();
        if (buildOnStart)
        {
            BuildLantern();
        }
    }

    private void Update()
    {
        if (_outerRoot != null && spinOuterLantern && outerSpinRpm > 0f)
        {
            float outerDegPerSecond = outerSpinRpm * 6f;
            _outerRoot.Rotate(Vector3.up, outerDegPerSecond * Time.deltaTime, Space.Self);
        }

        if (_innerRoot != null && spinInnerLamp && spinRpm > 0f)
        {
            float degPerSecond = spinRpm * 6f;
            _innerRoot.Rotate(Vector3.up, degPerSecond * Time.deltaTime, Space.Self);
        }

        if (_suspensionPivot != null && stabilizationStrength > 0f)
        {
            Quaternion target = Quaternion.FromToRotation(_suspensionPivot.up, Vector3.up) * _suspensionPivot.rotation;
            _suspensionPivot.rotation = Quaternion.Slerp(
                _suspensionPivot.rotation,
                target,
                Time.deltaTime * stabilizationStrength
            );
        }

        if (_innerLight != null && light_type == LanternLightType.Candle)
        {
            float t = Time.time * 7.5f;
            float noise = Mathf.PerlinNoise(_candleSeed, t) * 2f - 1f;
            _innerLight.intensity = 1.55f + noise * 0.30f;
            _innerLight.range = 0.88f + noise * 0.06f;
        }
    }

    [ContextMenu("Rebuild Lantern")]
    public void BuildLantern()
    {
        EnsurePalettes();
        if (applyScalePreset)
        {
            ApplyScalePreset();
        }
        SanitizeParams();
        ClearChildren();

        LanternPalette palette = palettes[_paletteIndex];
        ResolveStyleColors(palette, out Color frameColor, out Color shellColor, out Color coreColor, out Color chainColor);

        Material frameMat = CreateMaterial(frameColor, 0.10f, 0.30f);
        Material shellMat = CreateMaterial(shellColor, 0.02f, 0.35f);
        Material coreMat = CreateMaterial(coreColor, 0.05f, 0.45f);
        Material chainMat = CreateMaterial(chainColor, 0.58f, 0.62f);
        Material wireMat = CreateMaterial(new Color(0.24f, 0.24f, 0.26f, 1f), 0.75f, 0.30f);

        _outerRoot = new GameObject("OuterLantern").transform;
        _outerRoot.SetParent(transform, false);

        BuildOuterCage(_outerRoot, frameMat);
        BuildEquatorBands(_outerRoot, frameMat);
        BuildStyleDecoration(_outerRoot, frameMat, chainMat);

        Transform suspensionRoot = new GameObject("Suspension").transform;
        suspensionRoot.SetParent(transform, false);
        suspensionRoot.localPosition = BuildSuspensionOffset();
        _suspensionPivot = BuildSuspension(suspensionRoot, frameMat);

        _innerRoot = new GameObject("InnerLamp").transform;
        _innerRoot.SetParent(_suspensionPivot, false);
        CreateInnerLantern(_innerRoot, frameMat, shellMat, coreMat, wireMat);

        CreateLightSource(_innerRoot);
        UpdateInteractionCollider();
        ApplyOverallScale();
    }

    public void GenerateGunDeng(RollingLanternModelParams modelParams)
    {
        if (modelParams == null)
        {
            BuildLantern();
            return;
        }

        D_outer = modelParams.D_outer;
        D_inner = modelParams.D_inner;
        n_outer_ribs = modelParams.n_outer_ribs;
        n_inner_ribs = modelParams.n_inner_ribs;
        rib_width = modelParams.rib_width;
        rib_thickness = modelParams.rib_thickness;
        n_equator_bands = modelParams.n_equator_bands;
        suspension_type = modelParams.suspension_type;
        suspension_offset = modelParams.suspension_offset;
        cover_type = modelParams.cover_type;
        style_type = modelParams.style_type;
        chain_weight = modelParams.chain_weight;
        light_type = modelParams.light_type;
        scale_type = modelParams.scale_type;
        BuildLantern();
    }

    public void SetSpinRpm(float rpm)
    {
        spinRpm = Mathf.Max(0f, rpm);
    }

    public void SetOuterSpinRpm(float rpm)
    {
        outerSpinRpm = Mathf.Max(0f, rpm);
    }

    public void SetOverallScale(float scale)
    {
        overallScale = Mathf.Max(0.1f, scale);
        ApplyOverallScale();
    }

    public void RotateOuterByDegrees(float yawDegrees)
    {
        if (_outerRoot != null)
        {
            _outerRoot.Rotate(Vector3.up, yawDegrees, Space.Self);
            return;
        }

        transform.Rotate(Vector3.up, yawDegrees, Space.World);
    }

    public void NextPalette()
    {
        EnsurePalettes();
        int next = (_paletteIndex + 1) % palettes.Length;
        if (next == 0)
        {
            style_type = style_type == LanternStyleType.Wen ? LanternStyleType.Wu : LanternStyleType.Wen;
        }
        ApplyPalette(next, true);
    }

    public void ApplyPalette(int index, bool rebuild)
    {
        EnsurePalettes();
        _paletteIndex = Mathf.Clamp(index, 0, palettes.Length - 1);
        if (rebuild)
        {
            BuildLantern();
        }
    }

    private void ApplyScalePreset()
    {
        switch (scale_type)
        {
            case LanternScaleType.Small:
                D_outer = 0.36f;
                D_inner = 0.12f;
                n_equator_bands = DefaultOuterRingCount;
                break;
            case LanternScaleType.Medium:
                D_outer = 0.72f;
                D_inner = 0.23f;
                n_equator_bands = DefaultOuterRingCount;
                break;
            case LanternScaleType.Large:
                D_outer = style_type == LanternStyleType.Wu ? 1.50f : 1.20f;
                D_inner = D_outer * 0.32f;
                n_equator_bands = LargeOuterRingCount;
                break;
        }

        n_outer_ribs = TraditionalOuterOrbitCount;
        n_inner_ribs = 6;
    }

    private void SanitizeParams()
    {
        D_outer = Mathf.Max(0.15f, D_outer);
        D_inner = Mathf.Clamp(D_inner, 0.05f, D_outer * 0.45f);
        n_outer_ribs = TraditionalOuterOrbitCount;
        n_inner_ribs = Mathf.Max(4, n_inner_ribs);
        rib_width = Mathf.Max(0.002f, rib_width);
        rib_thickness = Mathf.Clamp(rib_thickness, 0.001f, rib_width);
        n_equator_bands = Mathf.Clamp(n_equator_bands, 2, MaxOuterRingCount);
        arcSegments = Mathf.Max(12, arcSegments);
    }

    private void BuildOuterCage(Transform parent, Material frameMat)
    {
        for (int i = 0; i < TraditionalOuterOrbitCount; i++)
        {
            Vector3 normal = GetOuterRibNormal(i, TraditionalOuterOrbitCount);
            CreateGreatCircle(
                parent,
                OuterRadius,
                normal,
                rib_width,
                rib_thickness,
                arcSegments,
                frameMat,
                $"OuterRib_{i}"
            );
        }
    }

    private void BuildEquatorBands(Transform parent, Material frameMat)
    {
        int bands = Mathf.Clamp(n_equator_bands, 2, MaxOuterRingCount);
        for (int i = 0; i < bands; i++)
        {
            float offset = GetBandOffset(i, bands, OuterRadius * OuterRingMaxOffsetFactor);

            CreateOrientedOffsetRing(
                parent,
                OuterRadius,
                Vector3.up,
                offset,
                rib_width * 1.00f,
                rib_thickness * 0.95f,
                arcSegments,
                frameMat,
                $"EquatorBand_{i}"
            );
        }
    }

    private static float GetBandOffset(int index, int totalBands, float maxOffset)
    {
        if (totalBands <= 2)
        {
            return index == 0 ? -maxOffset : maxOffset;
        }

        if (totalBands == 3)
        {
            if (index == 0) return -maxOffset;
            if (index == 1) return 0f;
            return maxOffset;
        }

        // For 4 bands, keep two near the shoulders and two near outer caps to reduce central clutter.
        float near = maxOffset * 0.32f;
        if (index == 0) return -maxOffset;
        if (index == 1) return -near;
        if (index == 2) return near;
        return maxOffset;
    }

    private void BuildStyleDecoration(Transform parent, Material frameMat, Material chainMat)
    {
        if (style_type != LanternStyleType.Wu || chain_weight <= 0f)
        {
            return;
        }

        int links = Mathf.Clamp(10 + Mathf.RoundToInt(chain_weight * 0.6f), 10, 80);
        float linkRadius = Mathf.Lerp(0.004f, 0.013f, Mathf.Clamp01(chain_weight / 50f));
        float ringRadius = OuterRadius * 0.93f;

        CreateChainOrbit(parent, ringRadius, Vector3.right, links, linkRadius, chainMat, "ChainOrbitA");
        CreateChainOrbit(parent, ringRadius, Vector3.forward, links, linkRadius, chainMat, "ChainOrbitB");
        CreateChainOrbit(parent, ringRadius, new Vector3(1f, 1f, 0f).normalized, links, linkRadius, chainMat, "ChainOrbitC");
    }

    private Transform BuildSuspension(Transform parent, Material frameMat)
    {
        float supportWidth = rib_width * 0.72f;
        float supportThickness = rib_thickness * 0.75f;
        float anchorRadius = Mathf.Max(InnerRadius * 1.18f, rib_width * 4f);

        Transform pivot = new GameObject("Pivot").transform;
        pivot.SetParent(parent, false);

        if (!showSuspensionFrame)
        {
            return pivot;
        }

        float topY = OuterRadius * 0.78f;
        float bottomY = -topY;

        switch (suspension_type)
        {
            case LanternSuspensionType.SingleAxis:
            {
                CreateStraightRib(parent, new Vector3(0f, topY, 0f), Vector3.zero, supportWidth, supportThickness, frameMat, "SingleAxisTop");
                CreateStraightRib(parent, new Vector3(0f, bottomY, 0f), Vector3.zero, supportWidth, supportThickness, frameMat, "SingleAxisBottom");
                CreateGreatCircle(parent, anchorRadius, Vector3.right, supportWidth, supportThickness, Mathf.Max(16, arcSegments / 2), frameMat, "SingleAxisRing");
                break;
            }
            case LanternSuspensionType.DualAxis:
            {
                Transform outerRing = new GameObject("DualOuterRing").transform;
                outerRing.SetParent(parent, false);
                CreateGreatCircle(outerRing, anchorRadius * 1.05f, Vector3.right, supportWidth, supportThickness, Mathf.Max(16, arcSegments / 2), frameMat, "DualRingA");

                Transform innerRing = new GameObject("DualInnerRing").transform;
                innerRing.SetParent(outerRing, false);
                CreateGreatCircle(innerRing, anchorRadius * 0.90f, Vector3.forward, supportWidth, supportThickness, Mathf.Max(16, arcSegments / 2), frameMat, "DualRingB");

                pivot.SetParent(innerRing, false);
                CreateStraightRib(parent, new Vector3(0f, topY, 0f), Vector3.zero, supportWidth, supportThickness, frameMat, "DualTop");
                CreateStraightRib(parent, new Vector3(0f, bottomY, 0f), Vector3.zero, supportWidth, supportThickness, frameMat, "DualBottom");
                CreateStraightRib(parent, new Vector3(OuterRadius * 0.75f, 0f, 0f), Vector3.zero, supportWidth, supportThickness, frameMat, "DualSideA");
                CreateStraightRib(parent, new Vector3(-OuterRadius * 0.75f, 0f, 0f), Vector3.zero, supportWidth, supportThickness, frameMat, "DualSideB");
                break;
            }
            case LanternSuspensionType.Gimbal:
            {
                Transform ringA = new GameObject("GimbalRingA").transform;
                ringA.SetParent(parent, false);
                CreateGreatCircle(ringA, anchorRadius * 1.15f, Vector3.up, supportWidth, supportThickness, Mathf.Max(16, arcSegments / 2), frameMat, "GimbalA");

                Transform ringB = new GameObject("GimbalRingB").transform;
                ringB.SetParent(ringA, false);
                CreateGreatCircle(ringB, anchorRadius * 1.00f, Vector3.right, supportWidth, supportThickness, Mathf.Max(16, arcSegments / 2), frameMat, "GimbalB");

                Transform ringC = new GameObject("GimbalRingC").transform;
                ringC.SetParent(ringB, false);
                CreateGreatCircle(ringC, anchorRadius * 0.86f, Vector3.forward, supportWidth, supportThickness, Mathf.Max(16, arcSegments / 2), frameMat, "GimbalC");

                pivot.SetParent(ringC, false);
                CreateStraightRib(parent, new Vector3(0f, topY, 0f), Vector3.zero, supportWidth, supportThickness, frameMat, "GimbalTop");
                CreateStraightRib(parent, new Vector3(0f, bottomY, 0f), Vector3.zero, supportWidth, supportThickness, frameMat, "GimbalBottom");
                break;
            }
        }

        return pivot;
    }

    private void CreateInnerLantern(Transform parent, Material frameMat, Material shellMat, Material coreMat, Material wireMat)
    {
        float lampSphereDiameter = D_inner * 0.58f;
        float lampSphereRadius = lampSphereDiameter * 0.5f;
        float supportRingRadius = InnerRadius * innerSupportRingScale;

        if (addInnerSupportRing)
        {
            CreateGreatCircle(
                parent,
                supportRingRadius,
                Vector3.forward,
                rib_width * 0.72f,
                rib_thickness * 0.72f,
                Mathf.Max(16, arcSegments / 2),
                frameMat,
                "InnerSupportRing"
            );
        }

        GameObject lampSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        lampSphere.name = "LampSphere";
        lampSphere.transform.SetParent(parent, false);
        lampSphere.transform.localScale = Vector3.one * lampSphereDiameter;
        RemoveCollider(lampSphere);
        lampSphere.GetComponent<Renderer>().material = cover_type == LanternCoverType.Paper ? shellMat : coreMat;

        CreateDualTractionLines(parent, wireMat, lampSphereRadius);
    }

    private void CreateDualTractionLines(Transform parent, Material lineMat, float lampSphereRadius)
    {
        if (!addDualTractionLines)
        {
            return;
        }

        float attachY = lampSphereRadius;
        float anchorY = OuterRadius;

        float width = Mathf.Max(0.0005f, tractionLineWidth);
        float thickness = Mathf.Max(0.0005f, tractionLineThickness);

        Transform tractionRoot = new GameObject("DualTractionLines").transform;
        tractionRoot.SetParent(parent, false);

        Vector3 topAnchor = new Vector3(0f, anchorY, 0f);
        Vector3 bottomAnchor = new Vector3(0f, -anchorY, 0f);
        Vector3 topAttach = new Vector3(0f, attachY, 0f);
        Vector3 bottomAttach = new Vector3(0f, -attachY, 0f);

        CreateStraightRib(tractionRoot, topAnchor, topAttach, width, thickness, lineMat, "TractionLine_Top");
        CreateStraightRib(tractionRoot, bottomAnchor, bottomAttach, width, thickness, lineMat, "TractionLine_Bottom");
    }

    private void CreateLightSource(Transform parent)
    {
        GameObject lightGO = new GameObject("InnerLight");
        lightGO.transform.SetParent(parent, false);
        lightGO.transform.localPosition = Vector3.zero;

        _innerLight = lightGO.AddComponent<Light>();
        _innerLight.type = LightType.Point;
        _innerLight.shadows = LightShadows.None;

        if (light_type == LanternLightType.Candle)
        {
            _candleSeed = Mathf.Abs(transform.position.x * 17.13f + transform.position.z * 9.71f) + 0.123f;
            _innerLight.color = new Color(1f, 0.75f, 0.42f, 1f);
            _innerLight.intensity = 1.65f;
            _innerLight.range = 0.85f;
        }
        else
        {
            _innerLight.color = new Color(1f, 0.38f, 0.18f, 1f);
            _innerLight.intensity = 1.85f;
            _innerLight.range = 1.05f;
        }
    }

    private Vector3 BuildSuspensionOffset()
    {
        if (suspension_offset <= 0f)
        {
            return Vector3.zero;
        }

        float x = SignedHash(D_outer * 17.31f + n_outer_ribs * 2.31f);
        float z = SignedHash(D_inner * 29.17f + n_inner_ribs * 1.17f);
        Vector3 offset = new Vector3(x, 0f, z).normalized * suspension_offset;
        return offset;
    }

    private Vector3 GetOuterRibNormal(int ribIndex, int totalRibs)
    {
        // Reserve two explicit vertical support orbits so top/bottom anchor points are structurally present.
        if (ribIndex < 2)
        {
            float supportYaw = ribIndex * 90f;
            return Quaternion.AngleAxis(supportYaw, Vector3.up) * Vector3.right;
        }

        // Keep the woven orbit style for the remaining ribs with five-point organization.
        const int starPoints = 5;
        int weavedIndex = ribIndex - 2;
        int starIndex = weavedIndex % starPoints;
        int familyIndex = weavedIndex / starPoints;
        int pentagramOrder = (starIndex * 2) % starPoints;

        float yaw = pentagramOrder * 72f;
        if (familyIndex % 2 == 1)
        {
            yaw += 36f;
        }

        // Mirror the orbit families across the center plane so their crossings stay between the two side rings.
        float baseTilt = Mathf.Clamp(58f + ribTiltDegrees * 0.25f, 46f, 72f);
        int mirroredFamilyIndex = familyIndex / 2;
        float familyTilt = Mathf.Max(18f, baseTilt - mirroredFamilyIndex * 5f);
        float signedTilt = familyIndex % 2 == 0 ? familyTilt : -familyTilt;

        Vector3 normal = Quaternion.AngleAxis(yaw, Vector3.up)
            * (Quaternion.AngleAxis(signedTilt, Vector3.right) * Vector3.up);

        return SafeNormalize(normal);
    }

    private void CreateGreatCircle(
        Transform parent,
        float radius,
        Vector3 normal,
        float width,
        float thickness,
        int segments,
        Material material,
        string rootName)
    {
        Vector3 n = SafeNormalize(normal);
        if (n == Vector3.zero)
        {
            n = Vector3.up;
        }

        Vector3 tangentA = SafeNormalize(Vector3.Cross(n, Vector3.up));
        if (tangentA == Vector3.zero)
        {
            tangentA = SafeNormalize(Vector3.Cross(n, Vector3.right));
        }
        Vector3 tangentB = SafeNormalize(Vector3.Cross(n, tangentA));

        Transform root = new GameObject(rootName).transform;
        root.SetParent(parent, false);

        for (int i = 0; i < segments; i++)
        {
            float a0 = i * Mathf.PI * 2f / segments;
            float a1 = (i + 1) * Mathf.PI * 2f / segments;
            Vector3 p0 = radius * (Mathf.Cos(a0) * tangentA + Mathf.Sin(a0) * tangentB);
            Vector3 p1 = radius * (Mathf.Cos(a1) * tangentA + Mathf.Sin(a1) * tangentB);

            if (cageIrregularity > 0f)
            {
                float n0 = 1f + SignedHash(i * 1.73f + radius * 19.7f) * cageIrregularity * 0.15f;
                float n1 = 1f + SignedHash((i + 1f) * 1.73f + radius * 19.7f) * cageIrregularity * 0.15f;
                p0 *= n0;
                p1 *= n1;
            }

            CreateStraightRib(root, p0, p1, width, thickness, material, $"{rootName}_Seg_{i}");
        }
    }

    private void CreateOrientedOffsetRing(
        Transform parent,
        float sphereRadius,
        Vector3 axis,
        float offset,
        float width,
        float thickness,
        int segments,
        Material material,
        string rootName)
    {
        float ringRadiusSq = sphereRadius * sphereRadius - offset * offset;
        if (ringRadiusSq <= 0.000001f)
        {
            return;
        }

        Vector3 up = SafeNormalize(axis);
        if (up == Vector3.zero)
        {
            up = Vector3.up;
        }
        Quaternion rotation = Quaternion.FromToRotation(Vector3.up, up);
        float ringRadius = Mathf.Sqrt(ringRadiusSq);
        Transform root = new GameObject(rootName).transform;
        root.SetParent(parent, false);

        for (int i = 0; i < segments; i++)
        {
            float a0 = i * Mathf.PI * 2f / segments;
            float a1 = (i + 1) * Mathf.PI * 2f / segments;
            Vector3 localP0 = new Vector3(Mathf.Cos(a0) * ringRadius, offset, Mathf.Sin(a0) * ringRadius);
            Vector3 localP1 = new Vector3(Mathf.Cos(a1) * ringRadius, offset, Mathf.Sin(a1) * ringRadius);
            Vector3 p0 = rotation * localP0;
            Vector3 p1 = rotation * localP1;
            CreateStraightRib(root, p0, p1, width, thickness, material, $"{rootName}_Seg_{i}");
        }
    }

    private void CreateChainOrbit(
        Transform parent,
        float radius,
        Vector3 normal,
        int links,
        float linkRadius,
        Material chainMat,
        string orbitName)
    {
        Vector3 n = SafeNormalize(normal);
        if (n == Vector3.zero)
        {
            n = Vector3.up;
        }

        Vector3 tangentA = SafeNormalize(Vector3.Cross(n, Vector3.up));
        if (tangentA == Vector3.zero)
        {
            tangentA = SafeNormalize(Vector3.Cross(n, Vector3.right));
        }
        Vector3 tangentB = SafeNormalize(Vector3.Cross(n, tangentA));

        Transform orbit = new GameObject(orbitName).transform;
        orbit.SetParent(parent, false);

        for (int i = 0; i < links; i++)
        {
            float a = i * Mathf.PI * 2f / links;
            Vector3 center = radius * (Mathf.Cos(a) * tangentA + Mathf.Sin(a) * tangentB);
            Vector3 tangent = SafeNormalize(-Mathf.Sin(a) * tangentA + Mathf.Cos(a) * tangentB);

            GameObject link = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            link.name = $"{orbitName}_Link_{i}";
            link.transform.SetParent(orbit, false);
            link.transform.localPosition = center;
            link.transform.localRotation = Quaternion.FromToRotation(Vector3.up, tangent);
            link.transform.localScale = new Vector3(linkRadius * 1.2f, linkRadius * 0.8f, linkRadius * 1.2f);
            RemoveCollider(link);
            link.GetComponent<Renderer>().material = chainMat;
        }
    }

    private static void CreateStraightRib(
        Transform parent,
        Vector3 start,
        Vector3 end,
        float width,
        float thickness,
        Material material,
        string ribName)
    {
        Vector3 dir = end - start;
        float length = dir.magnitude;
        if (length <= 0.0001f)
        {
            return;
        }

        GameObject rib = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rib.name = ribName;
        rib.transform.SetParent(parent, false);
        rib.transform.localPosition = (start + end) * 0.5f;
        rib.transform.localRotation = Quaternion.FromToRotation(Vector3.up, dir / length);
        rib.transform.localScale = new Vector3(width, length, thickness);
        RemoveCollider(rib);
        rib.GetComponent<Renderer>().material = material;
    }

    private void ResolveStyleColors(
        LanternPalette palette,
        out Color frameColor,
        out Color shellColor,
        out Color coreColor,
        out Color chainColor)
    {
        frameColor = palette.frameColor;
        shellColor = palette.innerShellColor;
        coreColor = palette.coreColor;
        chainColor = new Color(0.28f, 0.28f, 0.30f, 1f);

        if (style_type == LanternStyleType.Wen)
        {
            frameColor = Color.Lerp(frameColor, new Color(0.86f, 0.65f, 0.20f, 1f), 0.25f);
            shellColor = Color.Lerp(shellColor, new Color(0.85f, 0.10f, 0.10f, 1f), 0.20f);
            coreColor = Color.Lerp(coreColor, new Color(1f, 0.28f, 0.18f, 1f), 0.15f);
        }
        else
        {
            frameColor = Color.Lerp(frameColor, new Color(0.20f, 0.17f, 0.13f, 1f), 0.58f);
            shellColor = Color.Lerp(shellColor, new Color(0.58f, 0.05f, 0.05f, 1f), 0.42f);
            coreColor = Color.Lerp(coreColor, new Color(0.90f, 0.10f, 0.08f, 1f), 0.30f);
        }

        if (cover_type == LanternCoverType.Paper)
        {
            shellColor = Color.Lerp(shellColor, new Color(0.95f, 0.80f, 0.62f, 1f), 0.22f);
        }
    }

    private void EnsurePalettes()
    {
        if (palettes == null || palettes.Length == 0)
        {
            palettes = new[]
            {
                new LanternPalette
                {
                    paletteName = "Gold-Red",
                    frameColor = new Color(0.92f, 0.70f, 0.16f, 1f),
                    innerShellColor = new Color(0.88f, 0.08f, 0.10f, 1f),
                    coreColor = new Color(1.00f, 0.24f, 0.14f, 1f)
                },
                new LanternPalette
                {
                    paletteName = "Amber-Crimson",
                    frameColor = new Color(0.82f, 0.52f, 0.15f, 1f),
                    innerShellColor = new Color(0.75f, 0.08f, 0.07f, 1f),
                    coreColor = new Color(0.98f, 0.32f, 0.18f, 1f)
                },
                new LanternPalette
                {
                    paletteName = "Black-Garnet",
                    frameColor = new Color(0.32f, 0.30f, 0.28f, 1f),
                    innerShellColor = new Color(0.65f, 0.05f, 0.05f, 1f),
                    coreColor = new Color(1.00f, 0.30f, 0.18f, 1f)
                }
            };
        }

        if (!_palettesInitialized)
        {
            _paletteIndex = Mathf.Clamp(initialPaletteIndex, 0, palettes.Length - 1);
            _palettesInitialized = true;
        }
        else
        {
            _paletteIndex = Mathf.Clamp(_paletteIndex, 0, palettes.Length - 1);
        }
    }

    private void UpdateInteractionCollider()
    {
        if (!addInteractionCollider)
        {
            SphereCollider existing = GetComponent<SphereCollider>();
            if (existing != null)
            {
                DestroySafe(existing);
            }
            return;
        }

        SphereCollider collider = GetComponent<SphereCollider>();
        if (collider == null)
        {
            collider = gameObject.AddComponent<SphereCollider>();
        }

        collider.center = Vector3.zero;
        collider.radius = OuterRadius * interactionColliderScale;
    }

    private void ClearChildren()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            DestroySafe(transform.GetChild(i).gameObject);
        }

        _innerRoot = null;
        _outerRoot = null;
        _suspensionPivot = null;
        _innerLight = null;
    }

    private void ApplyOverallScale()
    {
        transform.localScale = Vector3.one * Mathf.Max(0.1f, overallScale);
    }

    private static Material CreateMaterial(Color color, float metallic, float smoothness)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null)
        {
            shader = Shader.Find("Standard");
        }

        Material mat = new Material(shader);
        mat.color = color;

        if (mat.HasProperty("_BaseColor"))
        {
            mat.SetColor("_BaseColor", color);
        }

        if (mat.HasProperty("_Metallic"))
        {
            mat.SetFloat("_Metallic", metallic);
        }

        if (mat.HasProperty("_Smoothness"))
        {
            mat.SetFloat("_Smoothness", smoothness);
        }

        return mat;
    }

    private static void RemoveCollider(GameObject target)
    {
        Collider c = target.GetComponent<Collider>();
        if (c != null)
        {
            DestroySafe(c);
        }
    }

    private static Vector3 SafeNormalize(Vector3 v)
    {
        if (v.sqrMagnitude <= 0.000001f)
        {
            return Vector3.zero;
        }
        return v.normalized;
    }

    private static float Hash01(float seed)
    {
        return Mathf.Repeat(Mathf.Sin(seed * 12.9898f + 78.233f) * 43758.5453f, 1f);
    }

    private static float SignedHash(float seed)
    {
        return Hash01(seed) * 2f - 1f;
    }

    private static void DestroySafe(Object obj)
    {
        if (obj == null)
        {
            return;
        }

        if (Application.isPlaying)
        {
            Destroy(obj);
        }
        else
        {
            DestroyImmediate(obj);
        }
    }
}
