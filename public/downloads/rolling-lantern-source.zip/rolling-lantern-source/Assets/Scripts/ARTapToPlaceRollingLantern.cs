using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

[RequireComponent(typeof(ARRaycastManager))]
public class ARTapToPlaceRollingLantern : MonoBehaviour
{
    [Header("References")]
    public ARPlaneManager planeManager;
    public Camera arCamera;
    public RollingLanternMVP rollingLanternPrefab;

    [Header("Placement")]
    public bool placeOnlyOnce = true;
    public bool hideDetectedPlanesAfterPlace = true;
    [Min(0f)] public float yOffset = 0.02f;

    [Header("Fallback Spawn")]
    public bool allowSpawnWithoutPlane = true;
    [Min(0.2f)] public float fallbackSpawnDistance = 1.0f;

    [Header("Interaction")]
    public bool tapLanternToCycleStyle = true;
    [Min(0.5f)] public float tapRayDistance = 5f;

    [Header("Rotation")]
    public bool dragToRotateLantern = true;
    [Min(0.01f)] public float dragRotateDegreesPerPixel = 0.25f;
    [Min(1f)] public float dragThresholdPixels = 10f;

    [Header("Scale")]
    public bool gestureScaleLantern = true;
    [Min(0.001f)] public float mouseWheelScaleStep = 0.08f;
    [Min(0.0001f)] public float pinchScaleFactor = 0.0025f;
    [Min(0.1f)] public float minLanternScale = 0.35f;
    [Min(0.2f)] public float maxLanternScale = 4.5f;

    private ARRaycastManager _raycastManager;
    private RollingLanternMVP _spawnedLantern;
    private bool _pointerDown;
    private bool _pressedOnLantern;
    private bool _draggingLantern;
    private Vector2 _pointerStartPos;
    private Vector2 _lastPointerPos;
    private bool _pinchActive;
    private float _lastPinchDistance;

    private static readonly List<ARRaycastHit> Hits = new List<ARRaycastHit>();

    public event Action<RollingLanternMVP> LanternPlaced;

    public RollingLanternMVP CurrentLantern => _spawnedLantern;

    private void Awake()
    {
        _raycastManager = GetComponent<ARRaycastManager>();

        if (arCamera == null)
        {
            arCamera = Camera.main;
        }
    }

    private void Update()
    {
        HandleScaleInput();
        HandlePointerDown();
        HandlePointerDrag();
        HandlePointerUp();
    }

    public void ClearPlacedLantern()
    {
        if (_spawnedLantern == null)
        {
            return;
        }

        Destroy(_spawnedLantern.gameObject);
        _spawnedLantern = null;
        ResetPointerGesture();
        SetPlanesVisible(true);
    }

    private void HandlePointerDown()
    {
        if (_pinchActive)
        {
            return;
        }

        if (_pointerDown || !TryGetPointerDownPosition(out Vector2 screenPos))
        {
            return;
        }

        _pointerDown = true;
        _pressedOnLantern = _spawnedLantern != null && IsTapOnLantern(screenPos);
        _draggingLantern = false;
        _pointerStartPos = screenPos;
        _lastPointerPos = screenPos;
    }

    private void HandlePointerDrag()
    {
        if (_pinchActive)
        {
            return;
        }

        if (!_pointerDown || !_pressedOnLantern || !dragToRotateLantern || _spawnedLantern == null)
        {
            return;
        }

        if (!TryGetPointerHeldPosition(out Vector2 screenPos))
        {
            return;
        }

        float threshold = Mathf.Max(1f, dragThresholdPixels);
        if (!_draggingLantern && (screenPos - _pointerStartPos).sqrMagnitude >= threshold * threshold)
        {
            _draggingLantern = true;
        }

        if (_draggingLantern)
        {
            Vector2 frameDelta = screenPos - _lastPointerPos;
            float yawDelta = -frameDelta.x * dragRotateDegreesPerPixel;
            _spawnedLantern.RotateOuterByDegrees(yawDelta);
        }

        _lastPointerPos = screenPos;
    }

    private void HandlePointerUp()
    {
        if (_pinchActive)
        {
            return;
        }

        if (!_pointerDown || !TryGetPointerUpPosition(out Vector2 screenPos))
        {
            return;
        }

        bool wasDrag = _draggingLantern;
        ResetPointerGesture();

        if (!wasDrag)
        {
            HandleTap(screenPos);
        }
    }

    private void HandleTap(Vector2 screenPos)
    {
        if (_spawnedLantern != null && tapLanternToCycleStyle && IsTapOnLantern(screenPos))
        {
            _spawnedLantern.NextPalette();
            return;
        }

        Pose fallbackPose = default;
        bool hasPlaneHit = _raycastManager.Raycast(screenPos, Hits, TrackableType.PlaneWithinPolygon);
        if (!hasPlaneHit && !TryGetFallbackPose(out fallbackPose))
        {
            return;
        }

        Pose targetPose = hasPlaneHit ? Hits[0].pose : fallbackPose;
        Vector3 placePos = targetPose.position + Vector3.up * yOffset;

        float yaw = 0f;
        if (arCamera != null)
        {
            yaw = arCamera.transform.eulerAngles.y;
        }
        Quaternion placeRot = Quaternion.Euler(0f, yaw, 0f);

        if (_spawnedLantern == null)
        {
            _spawnedLantern = SpawnLantern(placePos, placeRot);

            if (hideDetectedPlanesAfterPlace)
            {
                SetPlanesVisible(false);
            }

            LanternPlaced?.Invoke(_spawnedLantern);
        }
        else if (!placeOnlyOnce)
        {
            _spawnedLantern.transform.SetPositionAndRotation(placePos, placeRot);
        }
    }

    private void ResetPointerGesture()
    {
        _pointerDown = false;
        _pressedOnLantern = false;
        _draggingLantern = false;
        _pointerStartPos = default;
        _lastPointerPos = default;
    }

    private void HandleScaleInput()
    {
        if (!gestureScaleLantern || _spawnedLantern == null)
        {
            _pinchActive = false;
            _lastPinchDistance = 0f;
            return;
        }

        if (TryGetPinchDistance(out float pinchDistance))
        {
            if (_pinchActive)
            {
                float delta = pinchDistance - _lastPinchDistance;
                ApplyScaleDelta(delta * pinchScaleFactor);
            }

            _pinchActive = true;
            _lastPinchDistance = pinchDistance;
            ResetPointerGesture();
            return;
        }

        _pinchActive = false;
        _lastPinchDistance = 0f;

        if (TryGetMouseScrollDelta(out float scrollDelta) && Mathf.Abs(scrollDelta) > 0.0001f)
        {
            ApplyScaleDelta(scrollDelta * mouseWheelScaleStep);
        }
    }

    private void ApplyScaleDelta(float delta)
    {
        if (_spawnedLantern == null || Mathf.Abs(delta) <= 0.00001f)
        {
            return;
        }

        float nextScale = Mathf.Clamp(
            _spawnedLantern.overallScale + delta,
            minLanternScale,
            Mathf.Max(minLanternScale, maxLanternScale)
        );

        _spawnedLantern.SetOverallScale(nextScale);
    }

    private RollingLanternMVP SpawnLantern(Vector3 position, Quaternion rotation)
    {
        RollingLanternMVP lantern;

        if (rollingLanternPrefab != null)
        {
            lantern = Instantiate(rollingLanternPrefab, position, rotation);
        }
        else
        {
            GameObject lanternRoot = new GameObject("RollingLantern");
            lanternRoot.transform.SetPositionAndRotation(position, rotation);
            lantern = lanternRoot.AddComponent<RollingLanternMVP>();
            lantern.buildOnStart = false;
            lantern.BuildLantern();
        }

        return lantern;
    }

    private bool IsTapOnLantern(Vector2 screenPos)
    {
        if (arCamera == null || _spawnedLantern == null)
        {
            return false;
        }

        Ray ray = arCamera.ScreenPointToRay(screenPos);
        if (!Physics.Raycast(ray, out RaycastHit hit, tapRayDistance))
        {
            return false;
        }

        return hit.transform != null && hit.transform.IsChildOf(_spawnedLantern.transform);
    }

    private bool TryGetFallbackPose(out Pose fallbackPose)
    {
        if (!allowSpawnWithoutPlane || arCamera == null)
        {
            fallbackPose = default;
            return false;
        }

        Vector3 forward = arCamera.transform.forward;
        Vector3 position = arCamera.transform.position + forward * fallbackSpawnDistance;
        float yaw = arCamera.transform.eulerAngles.y;
        Quaternion rotation = Quaternion.Euler(0f, yaw, 0f);

        fallbackPose = new Pose(position, rotation);
        return true;
    }

    private bool TryGetPointerDownPosition(out Vector2 pos)
    {
#if ENABLE_INPUT_SYSTEM
        if (Touchscreen.current != null)
        {
            var primaryTouch = Touchscreen.current.primaryTouch;
            if (primaryTouch.press.wasPressedThisFrame)
            {
                pos = primaryTouch.position.ReadValue();
                return true;
            }
        }

        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            pos = Mouse.current.position.ReadValue();
            return true;
        }
#else
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Began)
            {
                pos = touch.position;
                return true;
            }
        }

        if (Input.GetMouseButtonDown(0))
        {
            pos = Input.mousePosition;
            return true;
        }
#endif

        pos = default;
        return false;
    }

    private bool TryGetPointerHeldPosition(out Vector2 pos)
    {
#if ENABLE_INPUT_SYSTEM
        if (Touchscreen.current != null)
        {
            var primaryTouch = Touchscreen.current.primaryTouch;
            if (primaryTouch.press.isPressed)
            {
                pos = primaryTouch.position.ReadValue();
                return true;
            }
        }

        if (Mouse.current != null && Mouse.current.leftButton.isPressed)
        {
            pos = Mouse.current.position.ReadValue();
            return true;
        }
#else
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            if (touch.phase == TouchPhase.Began || touch.phase == TouchPhase.Moved || touch.phase == TouchPhase.Stationary)
            {
                pos = touch.position;
                return true;
            }
        }

        if (Input.GetMouseButton(0))
        {
            pos = Input.mousePosition;
            return true;
        }
#endif

        pos = default;
        return false;
    }

    private bool TryGetPointerUpPosition(out Vector2 pos)
    {
#if ENABLE_INPUT_SYSTEM
        if (Touchscreen.current != null)
        {
            var primaryTouch = Touchscreen.current.primaryTouch;
            if (primaryTouch.press.wasReleasedThisFrame)
            {
                pos = primaryTouch.position.ReadValue();
                return true;
            }
        }

        if (Mouse.current != null && Mouse.current.leftButton.wasReleasedThisFrame)
        {
            pos = Mouse.current.position.ReadValue();
            return true;
        }
#else
        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch touch = Input.GetTouch(i);
            if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
            {
                pos = touch.position;
                return true;
            }
        }

        if (Input.GetMouseButtonUp(0))
        {
            pos = Input.mousePosition;
            return true;
        }
#endif

        pos = default;
        return false;
    }

    private bool TryGetPinchDistance(out float distance)
    {
#if ENABLE_INPUT_SYSTEM
        if (Touchscreen.current != null)
        {
            Vector2 first = default;
            Vector2 second = default;
            int count = 0;

            foreach (var touch in Touchscreen.current.touches)
            {
                if (!touch.press.isPressed)
                {
                    continue;
                }

                if (count == 0)
                {
                    first = touch.position.ReadValue();
                }
                else if (count == 1)
                {
                    second = touch.position.ReadValue();
                    distance = Vector2.Distance(first, second);
                    return true;
                }

                count++;
            }
        }
#else
        if (Input.touchCount >= 2)
        {
            distance = Vector2.Distance(Input.GetTouch(0).position, Input.GetTouch(1).position);
            return true;
        }
#endif

        distance = 0f;
        return false;
    }

    private bool TryGetMouseScrollDelta(out float scrollDelta)
    {
#if ENABLE_INPUT_SYSTEM
        if (Mouse.current != null)
        {
            scrollDelta = Mouse.current.scroll.ReadValue().y * 0.01f;
            return Mathf.Abs(scrollDelta) > 0.0001f;
        }
#else
        scrollDelta = Input.mouseScrollDelta.y;
        return Mathf.Abs(scrollDelta) > 0.0001f;
#endif

        scrollDelta = 0f;
        return false;
    }

    private void SetPlanesVisible(bool visible)
    {
        if (planeManager == null)
        {
            return;
        }

        planeManager.enabled = visible;

        foreach (ARPlane plane in planeManager.trackables)
        {
            plane.gameObject.SetActive(visible);
        }
    }
}
